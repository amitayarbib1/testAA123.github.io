module.exports = {
  darkMode: 'class', // This enables dark mode with a class
  // other Tailwind config settings...
};
